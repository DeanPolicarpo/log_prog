"""Desenvolva um programa que leia quatro notas e que apresente a média final."""

notas = []
for i in range(4):
    nota = float(input(f"Digite a nota {i + 1}: "))
    notas.append(nota)
media = sum(notas) / len(notas)
print(f"Média final: {media:.2f}")
