"""Desenvolva um programa que tenha uma função que verifique se um número inteiro qualquer é par ou impar."""
def verificar_par_impar(numero):
    if numero % 2 == 0:
        return "par"
    else:
        return "impar"


numero = int(input("Digite um número inteiro: "))
resultado = verificar_par_impar(numero)
print(f"O número {numero} é {resultado}.")