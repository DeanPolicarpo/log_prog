"""Desenvolva um programa que apresente na tela a seguinte mensagem: Hello World
Desenvolva um programa que pergunte o seu nome e, ao teclar Enter, apresente uma saudação personalizada"""

print("Hello World")

nome = input("Digite seu nome: ")
print(f"Olá, {nome}! Bem-vindo ao mundo da programação!")



