"""Desenvolva um programa que armazene quatro notas em uma lista e que apresente: a média final, a maior nota e a menor nota.
Desenvolva um programa que armazene quatro notas em uma lista e que apresente a média final. Caso a média seja igual ou superior a 7, apresentar a mensagem "APROVADO", caso contrário, armazenar a nota da prova final e recalcular a média. Caso a nova média seja igual superior a 5, apresentar a mensagem "APROVADO", caso contrário, apresentar a mensagem "REPROVADO"."""

notas = []
for i in range(4):
    nota = float(input(f"Digite a nota {i + 1}: "))
    notas.append(nota)
media = sum(notas) / len(notas)
print(f"Média final: {media:.2f}")

if media >= 7:
    print("APROVADO")
    
else:
    nota_final = float(input("Digite a nota da prova final: "))
    media_final = (media + nota_final) / 2
    print(f"Média final após a prova final: {media_final:.2f}")
    
    if media_final >= 5:
        print("APROVADO")
    else:
        print("REPROVADO")
        
        