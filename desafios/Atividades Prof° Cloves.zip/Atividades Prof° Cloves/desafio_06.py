"""Desenvolva um programa que leia um número inteiro qualquer e que apresete o número informado, seguido do seu antecessor e do seu sucessor."""

numero = int(input("Digite um número inteiro: "))
antecessor = numero - 1
sucessor = numero + 1
print(f"Número informado: {numero}")
print(f"Antecessor: {antecessor}")
print(f"Sucessor: {sucessor}")
