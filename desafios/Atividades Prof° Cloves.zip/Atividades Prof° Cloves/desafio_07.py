"""Desenvolva um programa que leia um número inteiro qualquer e que apresente o número informado com duas casas decimais."""

numero = float(input("Digite um número inteiro: "))
print(f"Número informado: {numero:.2f}")
