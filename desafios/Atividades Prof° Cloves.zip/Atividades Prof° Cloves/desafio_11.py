"""Desenvolva um programa que leia o seu nome completo e que apresente somente o seu primeiro e último nomes."""

nome_completo = input("Digite seu nome completo: ")
nomes = nome_completo.split()
primeiro_nome = nomes[0]
ultimo_nome = nomes[-1]
print(f"Primeiro nome: {primeiro_nome}")
print(f"Último nome: {ultimo_nome}")

