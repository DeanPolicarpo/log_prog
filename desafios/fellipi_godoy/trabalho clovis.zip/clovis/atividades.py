## Atividade 01

"""Básico
 Datas
 Carregue a data atual do computador e, com base na data atual, apresente a data de dois 
dias no futuro.
Carregue a data atual do computador e apresente somente a data."""

# from datetime import datetime, timedelta

# 1. Carregue a data atual do computador
import datetime


data_atual = datetime.datetime.now()

# 2. Com base na data atual, calcule a data de dois dias no futuro
data_futura = data_atual + datetime.timedelta(days=2)

# 3. Apresente as informações (formatadas para facilitar a leitura)
print("Data atual:", data_atual.strftime("%d/%m/%Y"))
print("Data de dois dias no futuro:", data_futura.strftime("%d/%m/%Y"))

## Atividade 02

"""Dicionários
Considere o seguinte dicionário: {'m1': {'m2': 'Olá Mundo'}}. Carregue e apresente a mensagem "Olá Mundo" contida no dicionário."""

dicionario = {'m1': {'m2': 'Olá Mundo'}}
print(dicionario['m1']['m2'])

## Atividade 03
"""Funções
Desenvolva um programa que tenha uma função que verifique se um número inteiro qualquer é par ou impar. O programa deve solicitar ao usuário que informe um número inteiro e, em seguida, chamar a função para verificar se o número é par ou ímpar, apresentando o resultado ao usuário."""

def verificar_par_impar(numero):
    if numero % 2 == 0:
        return "par"
    else:
        return "impar"


numero_usuario = int(input("Informe um número inteiro:"))

resultado = verificar_par_impar(numero_usuario)


print(f"O número {numero_usuario} é {resultado}.")


"""Listas
1. Desenvolva um programa que armazene quatro notas em uma lista e que apresente: a média final, a maior nota e a menor nota.
2. Desenvolva um programa que armazene quatro notas em uma lista e que apresente a média final. Caso a média seja igual ou superior a 7, apresentar a mensagem "APROVADO", caso contrário, armazenar a nota da prova final e recalcular a média. Caso a nova média seja igual superior a 5, apresentar a mensagem "APROVADO", caso contrário, apresentar a mensagem "REPROVADO"."""

nota1 = float(input("Informe a primeira nota: "))
nota2 = float(input("Informe a segunda nota: "))
nota3 = float(input("Informe a terceira nota: "))
nota4 = float(input("Informe a quarta nota: "))

notas = [nota1, nota2, nota3, nota4]
media_final = sum(notas) / len(notas)
maior_nota = max(notas)
menor_nota = min(notas)
print(f"Média final: {media_final:.2f}")
print(f"Maior nota: {maior_nota:.2f}")
print(f"Menor nota: {menor_nota:.2f}")

if media_final >= 7:
    print("APROVADO")
else:
    nota_final = float(input("Informe a nota da prova final: "))
    nova_media = (media_final + nota_final) / 2
    if nova_media >= 5:
        print("APROVADO")
    else:
        print("REPROVADO")


"""Mensagens
1. Desenvolva um programa que apresente na tela a seguinte mensagem: Hello World
2. Desenvolva um programa que pergunte o seu nome e, ao teclar Enter, apresente uma saudação personalizada, como por exemplo: "Olá, [seu nome]!"."""

print("Hello World")
nome_usuario = input("Qual é o seu nome? ")
print(f"Olá, {nome_usuario}!")


"""Números
1. Desenvolva um programa que leia um número inteiro qualquer e que apresete o número informado, seguido do seu antecessor e do seu sucessor.
2. Desenvolva um programa que leia um número inteiro qualquer e que apresente o número informado com duas casas decimais.
3. Desenvolva um programa que leia quatro notas e que apresente a média final.
4. Desenvolva um programa que leia um número inteiro qualquer e que informe se este número é par ou impar."""

numero = int(input("Informe um número inteiro: "))
antecessor = numero - 1
sucessor = numero + 1
print(f"Número informado: {numero}")
print(f"Antecessor: {antecessor}")
print(f"Sucessor: {sucessor}")


""" Strings
- Desenvolva um programa que altere em tempo de execução a palavra Java pela palavra Python na frase Exercícios de Java"""


frase = "Exercícios de Java"
nova_frase = frase.replace("Java", "Python")
print(nova_frase)


"""Avançado
1. Desenvolva um programa que leia o seu nome completo e que apresente somente o seu primeiro e último nomes.
2. Desenvolva um programa que leia um número qualquer e informe se ele é par ou ímpar.
3. Desenvolva uma calculadora rudimentar onde o usuário deve informar: qual operação ele deseja realizar, quais os valores para a realização do cálculo (apenas dois valores) e o resultado da operação"""

nome_completo = input("Informe seu nome completo: ")
partes_nome = nome_completo.split()
primeiro_nome = partes_nome[0]
ultimo_nome = partes_nome[-1]
print(f"Primeiro nome: {primeiro_nome}")
print(f"Último nome: {ultimo_nome}")

"""Map
1. Desenvolva um programa que converta todas as temperaturas desta lista em Celsius ([22.5, 40, 13, 29, 34]) para Fahrenheit"""

temperaturas_celsius = [22.5, 40, 13, 29, 34]
temperaturas_fahrenheit = list(map(lambda c: (c * 9/5) + 32, temperaturas_celsius))
print("Temperaturas em Fahrenheit:", temperaturas_fahrenheit)

# 2. Desenvolva um programa que apresente a soma dos valores pares e dos valores ímpares da sequência ([21, 5, 34, 8, 16, 7, 3])

numeros = [21, 5, 34, 8, 16, 7, 3]
soma_pares = sum(filter(lambda x: x % 2 == 0, numeros))
soma_impares = sum(filter(lambda x: x % 2 != 0, numeros))

print(f"Soma dos valores pares: {soma_pares}")
print(f"Soma dos valores ímpares: {soma_impares}")

## 3. Desenvolva um programa que apresente o maior e o menor valores da sequência ([54, 10, 29, 87, 7, 64])


numeros = [54, 10, 29, 87, 7, 64]
maior_valor = max(numeros)
menor_valor = min(numeros)
print(f"Maior valor: {maior_valor}")
print(f"Menor valor: {menor_valor}")


"""Projetos
- Jogos
1. Desenvolva um jogo de acerte o número, onde o computador escolhe um número inteiro aleatório de 0 a 10, e o usuário tem 5 tentativas para adivinhar o número
- OBS.: O design da tela pode ser implementado livremente
(PLUS): Implemente um sistema de pontuação com o seguinte comportamento: se o usuário adivinhar o número na primeira tentativa, receberá a pontuação máxima (ex. 100 pontos); se o usuário adivinhar o número na última tentativa, receberá a pontuação mínima (ex. 10 pontos); se o usuário não acertar o número, não receberá nenhum ponto.
(PLUS): Implemente um controle de erros. Caso o jogador digite um número fora da faixa permitida ou caracteres não numéricos, o sistema deve notificar o jogador e solicitar o input correto.
(PLUS): Implemente a opção de o usuário iniciar uma nova partida. Ao finalizar uma rodada, após o resultado final, o jogo deve perguntar se o jogador quer iniciar uma nova partida e, em caso negativo, encerrar a aplicação."""




## Criar um sistema que receba três notas dos alunos e saber a média, e saber se foi aprovado, recuperação ou reprovado.

def calcular_media(notas):
    return sum(notas) / len(notas)

nota1 = float(input("Informe a primeira nota: "))
nota2 = float(input("Informe a segunda nota: "))
nota3 = float(input("Informe a terceira nota: "))

notas = [nota1, nota2, nota3]
media_final = calcular_media(notas)

print(f"Média final: {media_final:.2f}")
if media_final >= 7:
    print("APROVADO")
elif media_final >= 5:
    print("RECUPERAÇÃO")        
else:
    print("REPROVADO")


def calcular_media(notas):
    return sum(notas) / len(notas)

nota1 = float(input("Informe a 1° nota: "))
nota2 = float(input("Informe a 2° nota: "))
nota3 = float(input("Informe a 3° nota: "))

notas = [nota1,nota2,nota3]
media_final = calcular_media(notas)
print(f"Média final: {media_final:.2f}")

if media_final >= 7:
    print("O aluno foi aprovado")
elif media_final >= 5:
    print("O aluno está em recuperação")
else:
    print("O aluno foi reprovado")


## Crie um sistema com um loop simples com um break para encerrar o programa, onde o usuário deve digitar um número inteiro e o programa deve apresentar o dobro do número informado. O programa deve continuar solicitando números até que o usuário digite um número negativo, momento em que o programa deve ser encerrado.

while True:
    numero = int(input("Digite um número inteiro (digite um número negativo para encerrar): "))
    
    if numero < 0:
        print("Programa encerrado.")
        break
    
    dobro = numero * 2
    print(f"O dobro de {numero} é {dobro}.")

# convertendo string em numero decimal correspondente

valor_string = "3.14"
valor_float = float(valor_string)
print(f"O valor convertido para float é: {valor_float}")


nome = "Python"
print(nome[1:4])  # Saída: "tho"

    


lista = [1, 2, 3]
lista.append(4)
print(len(lista))

print('A' + 'B' * 2)


# O que imprime

list(range(2, 10, 3))
print(list(range(2, 10, 3)))

# Crie uma tupla e imprima

tupla = (1, 2, 3, 4, 5)
print(tupla)  


print(type(10.0))

# valor de a    

a = 10
b = 20
a, b = b, a
print(f"a: {a}, b: {b}")
    
for i in range(1, 10, 2):
    print(i)

numero = "Amor" * 10
print(numero)

a = float(input("Digite o primeiro número: "))
b = float(input("Digite o segundo número: "))
op = input("Operador (+, -, *, /, %): ")

if op == "+":
    resultado = a + b
elif op == "-":
    resultado = a - b
elif op == "*":
    resultado = a * b
elif op == "/":
    if b != 0:
        resultado = a / b
    else:
        resultado = None
        print("Erro: divisão por zero.")
elif op == "%":
    if b != 0:
        resultado = a % b
    else:
        resultado = None
        print("Erro: divisão por zero.")
else:
    resultado = None
    print("Operador inválido.")

if resultado is not None:
    print(f"Resultado: {resultado}")


nota = int(input("Informe a nota do aluno: "))

if nota >= 9:
    conceito = 'A'
    mensagem = 'Excelente trabalho!'
elif nota >= 8:
    conceito = 'B'
    mensagem = 'Bom desempenho!'
elif nota >= 7:
    conceito = 'C'
    mensagem = 'Desempenho satisfatório'
elif nota >= 6:
    conceito = 'D'
    mensagem = 'Precisa melhorar'
else:
    conceito = 'F'
    mensagem = 'Reprovado'
print(f"Nota: {nota}")
print(f"Conceito: {conceito}")
print(mensagem)

##Você deve implementar um sistema de controle de acesso para um evento. O algoritmo deve receber a idade de um usuário e verificar: 1. Se a idade for menor que 16, acesso negado. 2. Se a idade estiver entre 16 e 17, acesso permitido apenas com autorização. 3. Se maior ou igual a 18, acesso livre. Qual estrutura lógica em Python melhor resolve este problema com clareza e eficiência? 


idade = int(input("Informe a idade do usuário: "))
if idade < 16:
    print("Acesso negado.")
elif 16 <= idade < 18:
    print("Acesso permitido apenas com autorização.")
else:    print("Acesso livre.")