#numeros
#Desenvolva um programa que leia um número inteiro qualquer e que informe se esse número é par ou impar.
num = int(input('digite um numero: '))
if num % 2 == 0:
    print('seu numero {} é par'.format(num))
else:
    print('seu numero {} é impar'.format(num))