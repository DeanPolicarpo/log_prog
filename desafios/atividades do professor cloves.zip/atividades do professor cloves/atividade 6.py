#mensagens
#Desenvolva um programa que apresenta na tela a seguinte mensagem: Hello World
print('hello world')