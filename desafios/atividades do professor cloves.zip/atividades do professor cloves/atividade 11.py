#projetos
#jogos
import random

def calcular_pontuacao(tentativa):
    pontos = {1: 100, 2: 80, 3: 60, 4: 30, 5: 10}
    return pontos[tentativa]

def jogar():
    numero_secreto = random.randint(0, 10)
    tentativas = 5

    print("\n" + "=" * 45)
    print("   🎯 Bem-vindo ao Jogo de Adivinhação! 🎯")
    print("=" * 45)
    nome = input("\nAntes de começar... qual é o seu nome? ")
    print("\nOlá, {}! Que bom ter você aqui! 😄".format(nome))
    print("Estou pensando em um número entre 0 e 10...")
    print("Você tem {} tentativas para adivinhar. Boa sorte! 🍀".format(tentativas))
    print("-" * 45)

    for tentativa in range(1, tentativas + 1):
        print("\n🔹 Tentativa {} de {}".format(tentativa, tentativas))

        while True:
            try:
                chute = int(input("{}, qual é o seu palpite? ".format(nome)))
                if chute < 0 or chute > 10:
                    print("Hmm... {} não está entre 0 e 10. Tente novamente! 😅".format(chute))
                else:
                    break
            except ValueError:
                print("Isso não parece um número... Tente digitar só números! 😬")

        if chute == numero_secreto:
            pontuacao = calcular_pontuacao(tentativa)
            if tentativa == 1:
                print("\n🤯 INCRÍVEL, {}! Acertou de primeira! Isso é sorte ou habilidade?".format(nome))
            elif tentativa <= 3:
                print("\n🎉 Muito bem, {}! Acertou na tentativa {}!".format(nome, tentativa))
            else:
                print("\n😅 Ufa, {}! Chegou lá na tentativa {}! Quase não dava!".format(nome, tentativa))
            print("🏆 Sua pontuação: {} pontos".format(pontuacao))
            return

        elif chute < numero_secreto:
            if tentativa < tentativas:
                print("Quase lá... mas o número que pensei é MAIOR que {}! 📈".format(chute))
            else:
                print("Tão perto, mas o número era MAIOR que {}! 😬".format(chute))
        else:
            if tentativa < tentativas:
                print("Boa tentativa! Mas o número é MENOR que {}! 📉".format(chute))
            else:
                print("Quase! Mas o número era MENOR que {}! 😬".format(chute))

        restantes = tentativas - tentativa
        if restantes == 1:
            print("⚠️  Cuidado, {}! Essa é sua ÚLTIMA chance!".format(nome))
        elif restantes > 1:
            print("Você ainda tem {} tentativas. Não desista! 💪".format(restantes))

    print("\n😢 Que pena, {}! Não foi dessa vez...".format(nome))
    print("O número que eu pensei era: {} 🙈".format(numero_secreto))
    print("💀 Pontuação: 0 pontos")

def main():
    while True:
        jogar()
        print("\n" + "=" * 45)
        nova = input("\nQuer tentar mais uma rodada? (s/n): ").strip().lower()
        if nova == 's':
            print("\nÓtimo! Vamos lá! 🚀")
        else:
            print("\nFoi um prazer jogar com você! Até a próxima! 👋😊")
            break

main()