#mapa
#Desenvolva um programa que apresenta a soma dos valores pares e dos valores ímpares da sequência ([21, 5, 34, 8, 16, 7, 3])
numeros = [21, 5, 34, 8, 16, 7, 3]

soma_pares = 0
soma_impares = 0

for num in numeros:
    if num % 2 == 0:
        soma_pares += num
    else:
        soma_impares += num

print("Soma dos pares: {}".format(soma_pares))
print("Soma dos ímpares: {}".format(soma_impares))