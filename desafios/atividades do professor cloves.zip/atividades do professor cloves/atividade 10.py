#Mapa
#Desenvolva um programa que converte todas as temperaturas desta lista em Celsius ([22.5, 40, 13, 29, 34]) para Fahrenheit
temperaturas_celsius = [22.5, 40, 13, 29, 34]

print("Celsius -> Fahrenheit")
for temp in temperaturas_celsius:
    fahrenheit = (temp * 9/5) + 32
    print("{} °C = {} °F".format(temp, fahrenheit))