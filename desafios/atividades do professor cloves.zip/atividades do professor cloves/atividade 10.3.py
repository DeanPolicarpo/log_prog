#mapa
#Desenvolve um programa que apresenta o maior e o menor valores da sequência ([54, 10, 29, 87, 7, 64])
numeros = [54, 10, 29, 87, 7, 64]

print("Maior valor: {}".format(max(numeros)))
print("Menor valor: {}".format(min(numeros)))