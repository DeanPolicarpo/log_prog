#listas
#Desenvolva um programa que armazene quatro notas em uma lista e que apresente: a média final, a nota maior e a nota menor.
notas = []
for i in range(4):
    nota = float(input('Digite a {}ª nota: '.format(i+1)))
    notas.append(nota)
media = sum(notas) / len(notas)
maior = max(notas)
menor = min(notas)

print('Média: {}'.format(media))
print('Maior nota: {}'.format(maior))
print('Menor nota: {}'.format(menor))