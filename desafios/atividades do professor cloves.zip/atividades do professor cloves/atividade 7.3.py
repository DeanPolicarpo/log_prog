#Desenvolva um programa que leia quatro notas e que apresente a média final.
n1 = float(input('digite a primeira nota: '))
n2 = float(input('digite a segunda nota: '))
n3 = float(input('digite a terceira nota: '))
n4 = float(input('digite a quarta nota: '))
media = (n1+n2+n3+n4) / 4
print('sua média foi de {:.2f}'.format(media))