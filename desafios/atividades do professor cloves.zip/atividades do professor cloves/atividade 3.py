#funções
#Desenvolva um programa que tenha uma função que verifique se um número inteiro qualquer é par ou impar
valor =int(input('digite um valor inteiro:'))
if valor % 2 == 0:
    print('o numero {} é par'.format(valor))
else:
    print('o numero {} é impar '.format(valor))