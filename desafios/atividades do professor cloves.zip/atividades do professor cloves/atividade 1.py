#atividade de dados
#exercicio 1:Carregue a data atual do computador e, com base na data atual, apresenta os dados de dois dias no futuro.
from datetime import datetime, timedelta
hoje = datetime.now().date()
futuro = hoje + timedelta(days=2)
print("Data atual: {}".format(hoje))
print("Data daqui a 2 dias: {}".format(futuro))
