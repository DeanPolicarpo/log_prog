#avançado
#Desenvolva uma calculadora rudimentar onde o usuário deve informar: qual operação ele deseja realizar, quais os valores para a realização do cálculo (apenas dois valores) e o resultado da operação
print("Escolha a operação:")
print("1 - Adição")
print("2 - Subtração")
print("3 - Multiplicação")
print("4 - Divisão")

operacao = int(input("Digite a opção desejada: "))

n1 = float(input("Digite o primeiro número: "))
n2 = float(input("Digite o segundo número: "))

if operacao == 1:
    print("Resultado: {}".format(n1 + n2))
elif operacao == 2:
    print("Resultado: {}".format(n1 - n2))
elif operacao == 3:
    print("Resultado: {}".format(n1 * n2))
elif operacao == 4:
    if n2 == 0:
        print("Erro: divisão por zero!")
    else:
        print("Resultado: {}".format(n1 / n2))
else:
    print("Opção inválida!")