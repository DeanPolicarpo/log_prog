#numeros
#Desenvolva um programa que leia um número inteiro qualquer e que apresente o número informado com duas casas decimais.
num = int(input('digite um numero inteiro qualquer: '))
print('seu numero é {:.2f}'.format(num))