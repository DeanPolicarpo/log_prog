#Avançado
#Desenvolva um programa que leia seu nome completo e que apresente apenas seu primeiro e último nomes.
nome_completo = input("Digite seu nome completo: ")
nomes = nome_completo.split()

print("Primeiro nome: {}".format(nomes[0]))
print("Último nome: {}".format(nomes[-1]))