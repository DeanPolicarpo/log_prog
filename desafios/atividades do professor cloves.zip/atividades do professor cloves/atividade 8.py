#cordas
#Desenvolva um programa que altere em tempo de execução a palavra Java pela palavra Python na frase Exercícios de Java
frase = "Exercícios de Java"
nova_frase = frase.replace("Java", "Python")
print(nova_frase)
