#numeros
#Desenvolva um programa que leia um número inteiro qualquer e que apresete o número informado, seguido do seu antecessor e do seu sucessor.
numero = int(input("Digite um numero inteiro: "))
print('seu numero informado é {}'.format(numero))
print('seu sucessor é {}'.format(numero+1))
print('seu antecessor é {}'.format(numero - 1))