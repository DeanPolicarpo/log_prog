#mensagens
#Desenvolva um programa que solicita o seu nome e, ao teclar Enter, apresenta uma saudação personalizada
nome = input('digite seu nome: ')
print('ola {} muito prazer em conhecer você!,seja bem vindo(a).'.format(nome))