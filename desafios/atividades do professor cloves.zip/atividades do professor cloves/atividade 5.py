#listas2
#Desenvolva um programa que armazene quatro notas em uma lista e que apresente a média final. Caso a média seja igual ou superior a 7, apresente a mensagem "APROVADO", caso contrário, armazene a nota da prova final e recalcular a média. Caso a nova média seja igual superior a 5, apresente a mensagem "APROVADO", caso contrário, apresente a mensagem "REPROVADO"
notas = []
for i in range(1, 5):
    nota = float(input(f"Digite a nota {i}: "))
    notas.append(nota)

media = sum(notas) / len(notas)
print(f"\nNotas: {notas}")
print(f"Média final: {media:.2f}")

if media >= 7:
    print("APROVADO")
else:
    print(f"Média insuficiente ({media:.2f}). Digite a nota da prova final:")
    nota_final = float(input("Nota da prova final: "))

    # Recalcular média com a prova final
    nova_media = (media + nota_final) / 2
    print(f"Nova média: {nova_media:.2f}")

    if nova_media >= 5:
        print("APROVADO")
    else:
        print("REPROVADO")