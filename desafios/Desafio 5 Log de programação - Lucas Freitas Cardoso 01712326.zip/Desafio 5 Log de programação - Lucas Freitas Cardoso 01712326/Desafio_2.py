from datetime import datetime

hoje = datetime.now()

print("Data atual:", hoje.date())