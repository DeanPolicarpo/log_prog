numero = float(input("Digite um número: "))
print(f"{numero:.2f}")