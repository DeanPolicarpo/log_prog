notas = []

for i in range(4):
    nota = float(input("Digite uma nota: "))
    notas.append(nota)

media = sum(notas) / len(notas)

print("Média:", media)

if media >= 7:
    print("APROVADO")
else:
    final = float(input("Digite a nota da prova final: "))
    nova_media = (media + final) / 2

    print("Nova média:", nova_media)

    if nova_media >= 5:
        print("APROVADO")
    else:
        print("REPROVADO")