numero = int(input("Digite um número inteiro: "))

print("Número informado:", numero)
print("Antecessor:", numero - 1)
print("Sucessor:", numero + 1)