from datetime import datetime, timedelta
hoje = datetime.now()
futuro = hoje + timedelta(days=2)

print("Data de Hoje:", hoje)
print("Data daqui a 2 dias:", futuro)