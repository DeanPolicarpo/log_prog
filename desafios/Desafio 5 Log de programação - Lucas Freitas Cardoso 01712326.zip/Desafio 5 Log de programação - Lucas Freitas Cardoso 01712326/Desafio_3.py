dados = {'m1': {'m2': 'Olá Mundo'}}
print(dados['m1']['m2'])