notas = []

for i in range(4):
    nota = float(input("Digite uma nota: "))
    notas.append(nota)

media = sum(notas) / len(notas)

print("Média final:", media)
print("Maior nota:", max(notas))
print("Menor nota:", min(notas))