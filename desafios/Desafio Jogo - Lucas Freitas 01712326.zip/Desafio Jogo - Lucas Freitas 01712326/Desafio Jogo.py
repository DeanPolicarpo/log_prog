import random

while True:
    numero_secreto = random.randint(0, 10)
    tentativas = 5
    acertou = False

    print("=" * 30)
    print("JOGO: ACERTE O NÚMERO")
    print("Escolhi um número de 0 a 10.")
    print("Você tem 5 tentativas.")
    print("=" * 30)

    for tentativa in range(1, tentativas + 1):

        while True:
            try:
                palpite = int(input(f"Tentativa {tentativa}: Digite um número: "))

                if palpite < 0 or palpite > 10:
                    print("Digite um número entre 0 e 10.")
                else:
                    break

            except ValueError:
                print("Digite apenas números inteiros.")

        if palpite == numero_secreto:
            pontos = 110 - (tentativa * 20)

            if pontos < 10:
                pontos = 10

            print("Parabéns! Você acertou!")
            print("Pontuação:", pontos)
            acertou = True
            break

        elif palpite < numero_secreto:
            print("O número é MAIOR.")

        else:
            print("O número é MENOR.")

    if not acertou:
        print("Ah não, Você perdeu!")
        print("O número era:", numero_secreto)
        print("Pontuação: 0")

    jogar_novamente = input("Deseja jogar novamente? (s/n): ").lower()

    if jogar_novamente != "s":
        print("Encerrando jogo...")
        break