"""Desenvolva um programa que converta todas as temperaturas desta lista em Celsius ([22,5, 40, 13, 29, 34]) para Fahrenheit"""

temperaturas_celsius = [22, 5, 40, 13, 29, 34]
temperaturas_fahrenheit = [(temp * 9/5) + 32 for temp in temperaturas_celsius]
print("Temperaturas em Celsius:", temperaturas_celsius)
print("Temperaturas convertidas para Fahrenheit:", temperaturas_fahrenheit)

