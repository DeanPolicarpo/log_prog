"""Desenvolva um programa que apresente a soma dos valores pares e dos valores ímpares da sequência ([21, 5, 34, 8, 16, 7, 3])"""

numeros = [21, 5, 34, 8, 16, 7, 3]
soma_pares = sum(num for num in numeros if num % 2 == 0)
soma_impares = sum(num for num in numeros if num % 2 != 0)
print(f"Soma dos valores pares: {soma_pares}")
print(f"Soma dos valores ímpares: {soma_impares}")

