print("Escolha a operação desejada:")
print("1 - Soma")
print("2 - Subtração")
print("3 - Multiplicação")
print("4 - Divisão")

operacao = input("\nDigite o número da operação (1, 2, 3 ou 4): ")


if operacao in ['1', '2', '3', '4']:
    valor1 = float(input("Digite o primeiro valor: "))
    valor2 = float(input("Digite o segundo valor: "))

    if operacao == "1":
        resultado = valor1 + valor2
        print(f"O resultado da soma é: {resultado}")
        
    elif operacao == "2":
        resultado = valor1 - valor2
        print(f"O resultado da subtração é: {resultado}")
        
    elif operacao == "3":
        resultado = valor1 * valor2
        print(f"O resultado da multiplicação é: {resultado}")
        
    elif operacao == "4":
        if valor2 != 0:
            resultado = valor1 / valor2
            print(f"O resultado da divisão é: {resultado}")
        else:
            print("Erro: Divisão por zero não é permitida.")
else:
    print("Opção inválida. Por favor, escolha um número de 1 a 4.")