"""Desenvolva um programa que apresente o maior e o menor valores da sequência ([54, 10, 29, 87, 7, 64])"""

numeros = [54, 10, 29, 87, 7, 64]
maior = max(numeros)
menor = min(numeros)
print(f"O maior valor da sequência é: {maior}")
print(f"O menor valor da sequência é: {menor}")
