dicionario = {'m1': {'m2': 'Olá Mundo'}}
mensagem = dicionario['m1']['m2']
print(mensagem)
