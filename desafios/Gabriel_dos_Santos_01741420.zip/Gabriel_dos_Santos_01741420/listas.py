notas = []
for i in range(4):
    nota = float(input(f"Digite a nota {i + 1}: "))
    notas.append(nota)
media = sum(notas) / len(notas)
print(f"Média final: {media:.2f}")

if media >= 7:
    print("APROVADO")
    
else:
    nota_final = float(input("Digite a nota da prova final: "))
    media_final = (media + nota_final) / 2
    print(f"Média final após a prova final: {media_final:.2f}")
    
    if media_final >= 5:
        print("Aprovado na prova final")
    else:
        print("Reprovado na prova final")
        
        