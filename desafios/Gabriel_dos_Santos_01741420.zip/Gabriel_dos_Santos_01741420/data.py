from datetime import datetime, timedelta
data_atual = datetime.now()
data_futura = data_atual + timedelta(days=2)
print("Data atual:", data_atual.strftime("%Y-%m-%d"))
print("Data de dois dias no futuro:", data_futura.strftime("%Y-%m-%d"))








