numero = float(input("Digite um número inteiro: "))
print(f"Número informado: {numero:.2f}")
